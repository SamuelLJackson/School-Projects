//File: negTest.cpp

#include <iostream>
using namespace std;

int main() {
  
  cout << -1 % 7 << endl;
  cout << 1 % 7 << endl;


  return 0;
}
